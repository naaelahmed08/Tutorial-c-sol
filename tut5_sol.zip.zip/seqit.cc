export module seqit;

export class SeqIt {
    int n;
    int(*fxn_ptr)(int);
      
public:
    SeqIt(int n, int(*fxn_ptr)(int));
    SeqIt& operator++();
    int operator*() const;
    bool operator!=(const SeqIt & other) const;
};

