module seqit;

SeqIt::SeqIt(int n, int(*fxn_ptr)(int)) : n{n}, fxn_ptr{fxn_ptr} {
    
}

SeqIt& SeqIt::operator++() {
    ++n;
    return *this;
}

int SeqIt::operator*() const {
    return fxn_ptr(n);
}

bool SeqIt::operator!=(const SeqIt & other) const {
    bool b = (n != other.n);
    if (b == false) {
        return fxn_ptr != other.fxn_ptr;
    }
    return b;
}
