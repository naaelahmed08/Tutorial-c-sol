import <iostream>;
import <string>;

using namespace std;

struct FriendList {
  string friends[8];
  int size = 0;
};

// Fill in the return type and arguments
istream & operator>>(istream & in, FriendList & list) {
  // Fill in this operator overload
  string name;
  in >> name;
  list.friends[list.size] = name;
  list.size = list.size + 1;
  return in;
}

// Fill in the return type and arguments
ostream & operator<<(ostream & out, FriendList & list) {
  // Fill in this operator overload
  out << "I have " << list.size<< " friend(s). They are:"<< endl;
  int comma_checker = 0;
  for (int i = 0; i < list.size; ++i){
    out << list.friends[i];
    if (comma_checker < list.size - 1){
      out << ", ";
    }
    ++ comma_checker;
  }
  out << endl;
  return out;
}

// For operator-, argument and return types are given
FriendList operator-(const FriendList& fl, int index) {
  // Fill in this operator overload
  // if (index > fl.size) break ;

  FriendList fl_copy = fl;
  
  for(int i = index; i < (fl_copy.size - 1); ++i ){
    fl_copy.friends[i] =fl_copy.friends[i+1];
  }
  fl_copy.size = fl_copy.size - 1; 
  return fl_copy;
}

int main() {
  FriendList theList;
  char c;
  while (cin >> c) {
    // Quit Program
    if (c == 'q') {
      break;
    } else if (c == 'a') {
      // Add friend
      cin >> theList;
    } else if (c == 'p') {
      // Print friends
      cout << theList;
    } else if (c == 'r') {
      // Remove friend at index
      int index;
      cin >> index;
      theList = theList - index;
    } // if
  } // while
} // main

