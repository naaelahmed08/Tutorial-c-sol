import <iostream>;
import <string>;
import <sstream>;
import <climits>;

using namespace std;

int main(){
    
    string s;
    string word;
    int wordcount;

    string larget_line;
    string smallest_line;

    int largest = INT_MIN;
    int smallest = INT_MAX;

    while ((getline(cin,s))){
        wordcount = 0;
        istringstream ss {s};
        while( ss>> word ){
            wordcount++;
        }
        
        if (wordcount > largest) {
            larget_line = s;
            largest = wordcount;
        } 
        
        if (wordcount < smallest){
            smallest_line = s;
            smallest = wordcount;
        }
    }

    cout<<smallest_line<<endl;
    cout<<larget_line<<endl;

    return 0;

}
