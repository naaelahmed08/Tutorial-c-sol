import racer;
import tortoise;
import hare;
import <iostream>;
using namespace std;

int main() {
    // Declares two pointers of type (Racer*), one pointing to a Hare object and one to a Tortoise object,
    // and runs a race between them. The program will then read a positive integer from standard input
    // that specifies the number of units, N, that the race will last. The race lasts until one of the
    // racers has covered N units of distance. Your main program should run a loop that keeps calling
    // the tick method of each Racer, stopping when one of them reaches N units of distance. Print out
    // "Tie" if they both reach N units of distance in the same time; otherwise print out either
    // "Hare" or "Tortoise" to indicate the winner.
    unsigned N;
    cin >> N;
    Racer * hare_1 = new Hare {};
    Racer * tortoise_1 = new Tortoise {};
    for(unsigned i = 0; i < N; ++i){
        (*hare_1).tick();
        (*tortoise_1).tick();
        cout<< "HI";
        if(tortoise_1 -> getDistance() == N) {
            cout << "Tortoise"<<endl;
        }
        if ( hare_1 -> getDistance() == N){
            cout << "Hare"<<endl;;
        }

        if(tortoise_1 -> getDistance() == N && hare_1 -> getDistance() == N){
            cout << "Tie"<<endl;
        }
    }
    
    delete hare_1;
    delete tortoise_1;
    return 0;
}
