module hare;

Hare::Hare():Racer{},tick_count{0}{}

Hare::~Hare() = default;

void Hare::tick() { 
    ++tick_count;
    if(tick_count < 11 || tick_count > 40){
    incDistance(2);
    }
}
