export module tortoise;
import racer;

export
class Tortoise: public Racer{
  // Fill in any needed data fields that aren't inherited.
   int tick_count;
  public:
  //Tortoise(unsigned int distance);
  ~Tortoise();
  void tick() override{};
};

