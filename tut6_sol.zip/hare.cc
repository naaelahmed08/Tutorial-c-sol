export module hare;
import racer;

export
class Hare: public Racer {
    // Fill in any needed data fields that aren't inherited.
    int tick_count;
  public:
    Hare(); // Can be removed if not needed.
    ~Hare();
    void tick();
};

