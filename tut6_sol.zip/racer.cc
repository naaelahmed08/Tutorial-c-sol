export module racer;

export
class Racer {
    unsigned int distance;
  public:
    Racer(); // initializes distance to 0
    unsigned getDistance() const;
    void incDistance(unsigned n);
    virtual ~Racer();
    virtual void tick() = 0; 

    // declare/define any other methods you need here
};
