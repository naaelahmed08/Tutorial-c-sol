module tortoise;
import racer;

//Tortoise::Tortoise(unsigned int distance): Racer{distance}{}

void Tortoise::tick() {
    ++ tick_count;
    incDistance(1);
 }

Tortoise:: ~Tortoise() = default;

