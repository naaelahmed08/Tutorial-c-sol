module racer;

Racer::Racer():distance{0}{}
unsigned Racer::getDistance() const { return this->distance; }
void Racer::incDistance(unsigned n) { distance += n; }
Racer::~Racer() = default;
